$(function () {
  $("#example").inputSliderRange({
    min: 0,
    max: 10000,
    start: 1700,
    step: 100,
  });
});

$(".ghost-btn, .btn-pop__link").click(function () {
  $(".btn-pop").toggleClass("d-none").css("order", "1");
  $(".btn-pop").toggleClass("d-block");
});

$(".burger, .close, .opened-menu__link").click(function () {
  $(".menu-opened").toggleClass("d-none").css("order", "1");
  $(".menu-opened").toggleClass("d-block");
});

$(".slider").slick({
  dots: false,
  infinite: true,
  speed: 500,
  slidesToShow: 3,
  slidesToScroll: 3,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        infinite: true,
        dots: false,
      },
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        infinite: true,
        dots: false,
      },
    },
  ],
});

$(".slider_products").slick({
  dots: false,
  infinite: true,
  speed: 500,
  slidesToShow: 2,
  slidesToScroll: 2,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        infinite: true,
        dots: false,
      },
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        infinite: true,
        dots: false,
      },
    },
  ],
});

if ($(window).width() < 576) {
  $(".slider_how .slick-prev, .slider_prod .slick-prev").addClass("d-none");
}

// Dropdown

function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

window.onclick = function (event) {
  if (!event.target.matches(".dropbtn")) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains("show")) {
        openDropdown.classList.remove("show");
      }
    }
  }
};
